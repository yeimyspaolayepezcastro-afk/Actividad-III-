package com.tecnocomfenalco.edurag.eduoptimaai.controller;

import com.tecnocomfenalco.edurag.eduoptimaai.model.Tutor;
import com.tecnocomfenalco.edurag.eduoptimaai.service.TutorService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/tutors")
public class TutorController {
    private final TutorService service;
    public TutorController(TutorService service) { this.service = service; }
    @GetMapping
    public String list(@RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="10") int size, Model model) {
        Page<Tutor> records = service.findAll(PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 50), Sort.by("id").descending()));
        model.addAttribute("tutors", records);
        return "tutors/list";
    }
    @GetMapping("/new")
    public String create(Model model) { model.addAttribute("tutor", new Tutor()); return "tutors/form"; }
    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("tutor") Tutor entity, BindingResult result) {
        if (result.hasErrors()) return "tutors/form";
        service.save(entity);
        return "redirect:/tutors";
    }
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) { model.addAttribute("tutor", service.findById(id)); return "tutors/form"; }
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) { service.deleteById(id); return "redirect:/tutors"; }
}
