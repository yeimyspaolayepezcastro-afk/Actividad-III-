package com.tecnocomfenalco.edurag.eduoptimaai.service;

import com.tecnocomfenalco.edurag.eduoptimaai.dto.*;
import com.tecnocomfenalco.edurag.eduoptimaai.model.Assignment;
import com.tecnocomfenalco.edurag.eduoptimaai.repository.AssignmentRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class OptimizationService {
    private final StudentService studentService;
    private final TutorService tutorService;
    private final AssignmentRepository assignmentRepository;
    private final RestClient restClient;
    @Value("${optimizer.api.url}") private String optimizerApiUrl;
    public OptimizationService(StudentService studentService, TutorService tutorService, AssignmentRepository assignmentRepository) {
        this.studentService=studentService; this.tutorService=tutorService; this.assignmentRepository=assignmentRepository; this.restClient=RestClient.create();
    }
    public OptimizationResponse optimize() {
        OptimizationRequest request = new OptimizationRequest(studentService.findAll(), tutorService.findAll());
        try {
            OptimizationResponse response = restClient.post().uri(optimizerApiUrl).body(request).retrieve().body(OptimizationResponse.class);
            if (response == null) throw new IllegalStateException("El optimizador devolvió una respuesta vacía");
            if ("Optimal".equalsIgnoreCase(response.getStatus()) && response.getAssignments()!=null) {
                LocalDateTime now=LocalDateTime.now();
                List<Assignment> records=response.getAssignments().stream().map(a -> new Assignment(a.getStudentId(),a.getStudentName(),a.getTutorId(),a.getTutorName(),a.getTopic(),a.getScore(),now)).toList();
                assignmentRepository.saveAll(records);
            }
            return response;
        } catch (RestClientException ex) {
            throw new IllegalStateException("No fue posible conectar con el microservicio de optimización. Verifica que FastAPI esté activo en " + optimizerApiUrl, ex);
        }
    }
    public List<Assignment> history() { return assignmentRepository.findAllByOrderByOptimizedAtDesc(); }
}
