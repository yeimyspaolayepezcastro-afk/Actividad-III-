package com.tecnocomfenalco.edurag.eduoptimaai.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(Exception.class)
    public String handle(Exception exception, Model model) {
        model.addAttribute("error", exception.getMessage()==null ? "Ocurrió un error inesperado" : exception.getMessage());
        return "error";
    }
}
