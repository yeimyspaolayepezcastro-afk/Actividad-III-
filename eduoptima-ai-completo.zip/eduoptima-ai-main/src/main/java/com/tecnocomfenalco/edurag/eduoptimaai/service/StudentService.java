package com.tecnocomfenalco.edurag.eduoptimaai.service;

import com.tecnocomfenalco.edurag.eduoptimaai.model.Student;
import com.tecnocomfenalco.edurag.eduoptimaai.repository.StudentRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StudentService {
    private final StudentRepository repository;
    public StudentService(StudentRepository repository) { this.repository = repository; }
    public List<Student> findAll() { return repository.findAll(); }
    public Page<Student> findAll(Pageable pageable) { return repository.findAll(pageable); }
    public Student findById(Long id) { return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Student no encontrado: " + id)); }
    public Student save(Student entity) { return repository.save(entity); }
    public void deleteById(Long id) { repository.deleteById(id); }
}
