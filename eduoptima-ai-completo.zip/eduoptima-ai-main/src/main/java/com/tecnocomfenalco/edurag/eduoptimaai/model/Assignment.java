package com.tecnocomfenalco.edurag.eduoptimaai.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="optimization_assignments")
public class Assignment {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private Long studentId;
    private String studentName;
    private Long tutorId;
    private String tutorName;
    private String topic;
    private int score;
    private LocalDateTime optimizedAt;
    public Assignment() {}
    public Assignment(Long studentId, String studentName, Long tutorId, String tutorName, String topic, int score, LocalDateTime optimizedAt) { this.studentId=studentId; this.studentName=studentName; this.tutorId=tutorId; this.tutorName=tutorName; this.topic=topic; this.score=score; this.optimizedAt=optimizedAt; }
    public Long getId(){return id;} public Long getStudentId(){return studentId;} public String getStudentName(){return studentName;} public Long getTutorId(){return tutorId;} public String getTutorName(){return tutorName;} public String getTopic(){return topic;} public int getScore(){return score;} public LocalDateTime getOptimizedAt(){return optimizedAt;}
}
