package com.tecnocomfenalco.edurag.eduoptimaai.service;

import com.tecnocomfenalco.edurag.eduoptimaai.model.Tutor;
import com.tecnocomfenalco.edurag.eduoptimaai.repository.TutorRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TutorService {
    private final TutorRepository repository;
    public TutorService(TutorRepository repository) { this.repository = repository; }
    public List<Tutor> findAll() { return repository.findAll(); }
    public Page<Tutor> findAll(Pageable pageable) { return repository.findAll(pageable); }
    public Tutor findById(Long id) { return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Tutor no encontrado: " + id)); }
    public Tutor save(Tutor entity) { return repository.save(entity); }
    public void deleteById(Long id) { repository.deleteById(id); }
}
