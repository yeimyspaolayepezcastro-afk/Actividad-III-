package com.tecnocomfenalco.edurag.eduoptimaai.controller;

import com.tecnocomfenalco.edurag.eduoptimaai.model.Student;
import com.tecnocomfenalco.edurag.eduoptimaai.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/students")
public class StudentController {
    private final StudentService service;
    public StudentController(StudentService service) { this.service = service; }
    @GetMapping
    public String list(@RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="10") int size, Model model) {
        Page<Student> records = service.findAll(PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 50), Sort.by("id").descending()));
        model.addAttribute("students", records);
        return "students/list";
    }
    @GetMapping("/new")
    public String create(Model model) { model.addAttribute("student", new Student()); return "students/form"; }
    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("student") Student entity, BindingResult result) {
        if (result.hasErrors()) return "students/form";
        service.save(entity);
        return "redirect:/students";
    }
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) { model.addAttribute("student", service.findById(id)); return "students/form"; }
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) { service.deleteById(id); return "redirect:/students"; }
}
