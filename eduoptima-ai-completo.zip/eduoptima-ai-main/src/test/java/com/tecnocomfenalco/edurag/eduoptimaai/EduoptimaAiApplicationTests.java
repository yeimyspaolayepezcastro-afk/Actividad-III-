package com.tecnocomfenalco.edurag.eduoptimaai;

import com.tecnocomfenalco.edurag.eduoptimaai.model.Student;
import com.tecnocomfenalco.edurag.eduoptimaai.repository.StudentRepository;
import com.tecnocomfenalco.edurag.eduoptimaai.service.StudentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EduoptimaAiApplicationTests {
    @Mock private StudentRepository repository;
    @InjectMocks private StudentService service;
    @Test void savesStudent() {
        Student student=new Student(null,"Ana","Matemáticas",4,9);
        when(repository.save(student)).thenReturn(new Student(1L,"Ana","Matemáticas",4,9));
        assertEquals(1L,service.save(student).getId());
        verify(repository).save(student);
    }
    @Test void findsStudentById() {
        Student student=new Student(1L,"Ana","Matemáticas",4,9);
        when(repository.findById(1L)).thenReturn(Optional.of(student));
        assertEquals("Ana",service.findById(1L).getName());
    }
    @Test void throwsWhenStudentDoesNotExist() {
        when(repository.findById(7L)).thenReturn(Optional.empty());
        assertThrows(IllegalArgumentException.class,()->service.findById(7L));
    }
    @Test void deletesStudent() {
        service.deleteById(1L);
        verify(repository).deleteById(1L);
    }
}
