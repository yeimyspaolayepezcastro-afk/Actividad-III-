# EduOptima AI

Sistema de asignación óptima de tutorías académicas mediante Spring Boot, Java 21, MySQL, Thymeleaf, FastAPI y PuLP/CBC.

## Requisitos
- Java 21+
- MySQL 8.x
- Python 3.10+
- Maven 3.9+

## Microservicio de optimización
```bash
cd optimizer-api
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```
En Windows active el entorno con `.venv\Scripts\activate`. La documentación interactiva está en `http://127.0.0.1:8000/docs`.

## Aplicación Spring Boot
Configure `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `APP_USERNAME`, `APP_PASSWORD` y `OPTIMIZER_API_URL` como variables de entorno. Los valores predeterminados son para desarrollo local. Ejecute:
```bash
./mvnw spring-boot:run
```
La aplicación estará en `http://localhost:8080`. Las rutas protegidas solicitan inicio de sesión; usuario predeterminado `admin`, contraseña `Admin123!`. Cambie estas credenciales antes de cualquier despliegue.

## Funcionalidad
- CRUD validado de estudiantes y tutores.
- Optimización entera binaria con objetivo de maximizar prioridad por riesgo académico.
- Restricciones: máximo un tutor por estudiante, capacidad por tutor y compatibilidad temática sin distinguir mayúsculas/minúsculas.
- Persistencia del historial de asignaciones.
- Paginación de listados, autenticación HTTP Basic/formulario, documentación OpenAPI y manejo de errores.
- Pruebas unitarias de servicios.

## Modelo matemático
Sea `x[i,j]` una variable binaria que indica la asignación del estudiante `i` al tutor `j`.

Maximizar `Z = sum(priority[i] * academicRisk[i] * x[i,j])` para pares temáticamente compatibles, sujeto a:
- `sum_j x[i,j] <= 1` para cada estudiante.
- `sum_i x[i,j] <= maxCapacity[j]` para cada tutor.
- `x[i,j] = 0` si el tema no coincide con la especialidad.
- `x[i,j]` binaria.

## Prueba directa del optimizador
Con FastAPI activo, abre `http://127.0.0.1:8000/docs` y ejecuta `POST /optimize`. También puedes enviar:
```bash
curl -X POST http://127.0.0.1:8000/optimize -H "Content-Type: application/json" -d '{"students":[{"id":1,"name":"Ana García","topic":"Matemáticas","academicRisk":4,"priority":9}],"tutors":[{"id":1,"name":"Carlos Ruiz","specialty":"Matemáticas","maxCapacity":3}]}'
```

## Pruebas
```bash
./mvnw test
```

## Glosario
- **Programación Lineal Entera (PLE):** modelo de optimización con variables enteras; aquí son binarias (0 o 1).
- **PuLP:** biblioteca Python para modelar problemas de optimización lineal.
- **CBC:** solver de código abierto usado por PuLP para programación lineal entera.
- **FastAPI:** framework para construir APIs REST con validación Pydantic y documentación Swagger.
- **Pydantic:** validación y deserialización de los datos de entrada del microservicio.
- **RestClient:** cliente HTTP síncrono de Spring para consumir el microservicio.
- **DTO:** objeto que transfiere datos entre capas o sistemas.
- **@Value:** inyecta valores de configuración de Spring.
- **Función objetivo:** expresión que el solver maximiza o minimiza.
- **Variable de decisión:** valor que el solver determina; en este modelo indica si existe una asignación.
- **Score de asignación:** producto de prioridad por riesgo académico.
- **Compatibilidad temática:** coincidencia sin distinguir mayúsculas/minúsculas entre tema y especialidad.
- **POST-Redirect-GET:** patrón que redirige después de guardar un formulario.
- **ddl-auto=update:** configuración Hibernate que actualiza el esquema; adecuada para desarrollo, no para producción.
