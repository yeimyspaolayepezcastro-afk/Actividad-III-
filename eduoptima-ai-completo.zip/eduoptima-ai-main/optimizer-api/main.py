from typing import List
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import pulp

app = FastAPI(title="EduOptima Optimizer API", description="API de optimización académica", version="1.0.0")

class Student(BaseModel):
    id: int
    name: str = Field(min_length=1)
    topic: str = Field(min_length=1)
    academicRisk: int = Field(ge=1, le=5)
    priority: int = Field(ge=1, le=10)

class Tutor(BaseModel):
    id: int
    name: str = Field(min_length=1)
    specialty: str = Field(min_length=1)
    maxCapacity: int = Field(ge=1)

class OptimizationRequest(BaseModel):
    students: List[Student]
    tutors: List[Tutor]

@app.get("/")
def home():
    return {"message": "Optimizer API funcionando"}

@app.post("/optimize")
def optimize(request: OptimizationRequest):
    students=request.students
    tutors=request.tutors
    problem=pulp.LpProblem("TutorAssignment", pulp.LpMaximize)
    x={(student.id,tutor.id): pulp.LpVariable(f"x_{student.id}_{tutor.id}",cat="Binary") for student in students for tutor in tutors}
    problem += pulp.lpSum(student.priority * student.academicRisk * x[(student.id,tutor.id)] for student in students for tutor in tutors if student.topic.strip().casefold()==tutor.specialty.strip().casefold())
    for student in students:
        problem += pulp.lpSum(x[(student.id,tutor.id)] for tutor in tutors) <= 1
    for tutor in tutors:
        problem += pulp.lpSum(x[(student.id,tutor.id)] for student in students) <= tutor.maxCapacity
    for student in students:
        for tutor in tutors:
            if student.topic.strip().casefold()!=tutor.specialty.strip().casefold():
                problem += x[(student.id,tutor.id)] == 0
    try:
        problem.solve(pulp.PULP_CBC_CMD(msg=False))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Error al ejecutar CBC: {exc}")
    status=pulp.LpStatus[problem.status]
    if status not in ("Optimal", "Infeasible", "Unbounded"):
        raise HTTPException(status_code=503, detail=f"El solver terminó con estado: {status}")
    assignments=[]
    for student in students:
        for tutor in tutors:
            if pulp.value(x[(student.id,tutor.id)]) == 1:
                assignments.append({"studentId":student.id,"studentName":student.name,"tutorId":tutor.id,"tutorName":tutor.name,"topic":student.topic,"score":student.priority*student.academicRisk})
    return {"status":status,"objectiveValue":float(pulp.value(problem.objective) or 0),"assignments":assignments}
